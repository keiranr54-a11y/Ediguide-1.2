# Ediguide — University Ranking Website (Git-ready)

This repo contains a static website (HTML/CSS/JS) ready for GitHub Pages.
It includes:
- index.html, methodology.html, privacy.html
- css/style.css
- js/main.js (with optional Firebase support)
- data/rankings.json

To deploy: push to GitHub and enable Pages on the main branch (root).

See below for git commands to push everything in one go.
