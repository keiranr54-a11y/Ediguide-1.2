/* Create this file to enable Firebase-backed persistent notes.
   Replace values with your Firebase project's config (from Firebase console).
   Example format:
window.FIREBASE_CONFIG = {
  apiKey: "API_KEY",
  authDomain: "PROJECT_ID.firebaseapp.com",
  databaseURL: "https://PROJECT_ID-default-rtdb.firebaseio.com",
  projectId: "PROJECT_ID",
  storageBucket: "PROJECT_ID.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};
*/

