/* main.js - includes Firebase persistent comments example.
   IMPORTANT: For Firebase persistence, create js/firebase-config.js with:
   window.FIREBASE_CONFIG = {
     apiKey: "...",
     authDomain: "...",
     databaseURL: "...",
     projectId: "...",
     storageBucket: "...",
     messagingSenderId: "...",
     appId: "..."
   };
   (Don't commit secrets to public repos if you don't want them visible.)
*/

const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

const LS_NOTES = 'ediguide_notes_v1';
const LS_RATINGS = 'ediguide_ratings_v1';

const state = { data: [], visible: [] };

document.addEventListener('DOMContentLoaded', async () => {
  // Try to load optional firebase config if the file exists (no error if not)
  loadOptionalScript('js/firebase-config.js').then(() => {
    if(window.FIREBASE_CONFIG) {
      initFirebase(window.FIREBASE_CONFIG);
    }
  }).catch(()=>{ /* ignore */ });

  bindUI();
  await loadData();
  initFilters();
  applyAll();
  renderNotes();
  document.getElementById('curYear').textContent = new Date().getFullYear();
});

function loadOptionalScript(src) {
  return new Promise((resolve,reject) => {
    fetch(src, {cache:'no-store'}).then(resp=>{
      if(!resp.ok) return reject();
      const s = document.createElement('script');
      s.src = src;
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    }).catch(reject);
  });
}

async function loadData(){
  try{
    const res = await fetch('data/rankings.json');
    const arr = await res.json();
    state.data = arr.map((x,i)=>({
      rank: Number(x.rank) || (i+1),
      university: x.university || x.name || '',
      country: x.country || '',
      score: (x.score===undefined||x.score===null)?null:Number(x.score),
      raw: x
    }));
  }catch(e){
    console.error('loadData',e);
    $('#results-info').textContent = 'Failed to load ranking data.';
  }
}

function initFilters(){
  const countries = Array.from(new Set(state.data.map(d=>d.country).filter(Boolean))).sort();
  const sel = $('#country');
  countries.forEach(c=>{
    const opt = document.createElement('option');
    opt.value = c; opt.textContent = c; sel.appendChild(opt);
  });
}

function bindUI(){
  ['#search','#country','#rank-min','#rank-max','#sort'].forEach(id=>{
    const el = document.querySelector(id);
    if(el) el.addEventListener('input', debounce(applyAll, 180));
  });
  $('#resetFilters').addEventListener('click', ()=>{ resetFilters(); applyAll(); });
  $('#exportCsv').addEventListener('click', ()=> exportToCSV(state.visible));
  $('#toggleCompact').addEventListener('click', ()=>{ document.body.classList.toggle('compact'); });
  $('#noteForm').addEventListener('submit', e=>{ e.preventDefault(); saveNote(); });
  $('#clearNotes').addEventListener('click', ()=>{ if(confirm('Clear local notes and ratings?')){ localStorage.removeItem(LS_NOTES); localStorage.removeItem(LS_RATINGS); renderNotes(); applyAll(); }});
}

function debounce(fn,wait=200){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a),wait); }; }

function applyAll(){
  const q = ($('#search').value||'').trim().toLowerCase();
  const country = $('#country').value;
  const min = parseInt($('#rank-min').value) || null;
  const max = parseInt($('#rank-max').value) || null;
  const sortVal = $('#sort').value || 'rank-asc';

  state.visible = state.data.filter(item=>{
    if(q){ const hay=(item.university+' '+item.country).toLowerCase(); if(!hay.includes(q)) return false; }
    if(country && item.country!==country) return false;
    if(min && item.rank<min) return false;
    if(max && item.rank>max) return false;
    return true;
  });

  state.visible.sort((a,b)=>{
    switch(sortVal){
      case 'rank-asc': return a.rank-b.rank;
      case 'rank-desc': return b.rank-a.rank;
      case 'score-asc': return (a.score||0)-(b.score||0);
      case 'score-desc': return (b.score||0)-(a.score||0);
      case 'name-asc': return a.university.localeCompare(b.university);
      case 'name-desc': return b.university.localeCompare(a.university);
      case 'country-asc': return a.country.localeCompare(b.country);
      default: return a.rank-b.rank;
    }
  });

  renderTable(state.visible);
  updateActiveFilters();
}

function resetFilters(){ $('#search').value=''; $('#country').value=''; $('#rank-min').value=''; $('#rank-max').value=''; $('#sort').value='rank-asc'; }

function updateActiveFilters(){
  const parts=[];
  const s = $('#search').value.trim(); if(s) parts.push(`Query: "${s}"`);
  const c = $('#country').value; if(c) parts.push(`Country: ${c}`);
  const min = $('#rank-min').value; const max = $('#rank-max').value;
  if(min||max) parts.push(`Rank: ${min||'1'}–${max||'∞'}`);
  $('#activeFilters').innerHTML = parts.length?parts.map(p=>`<li>${escapeHtml(p)}</li>`).join(''):'<li>None</li>';
  $('#results-info').textContent = `${state.visible.length} result${state.visible.length!==1?'s':''}`;
}

function renderTable(list){
  const tbody = document.querySelector('#rankingTable tbody');
  tbody.innerHTML = '';
  if(!list.length){ tbody.innerHTML = '<tr><td colspan="7" class="kv">No results found.</td></tr>'; updateActiveFilters(); return; }

  const ratings = loadRatings();
  const notes = loadNotes();

  list.forEach(item=>{
    const avg = ratings[item.university] ? (ratings[item.university].sum/ratings[item.university].count) : null;
    const nCount = notes.filter(n=>n.univ===item.university).length;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><span class="rank-badge">${item.rank}</span></td>
      <td><span class="univ-title">${escapeHtml(item.university)}</span><div class="kv">${escapeHtml(item.country)}</div></td>
      <td>${escapeHtml(item.country)}</td>
      <td>${item.score!==null?item.score:'—'}</td>
      <td><div class="ad-inner" style="padding:6px 8px;border-radius:6px;">Ad slot</div></td>
      <td class="rating-cell" data-univ="${escapeHtml(item.university)}">${renderStars(avg)}</td>
      <td>${nCount?`${nCount} note${nCount>1?'s':''}`:'-'}</td>
    `;
    tbody.appendChild(tr);
  });

  $$('.rating-cell .star').forEach(star=>{
    star.addEventListener('click',(e)=>{
      const cell = e.target.closest('.rating-cell'); const univ = cell.dataset.univ; const val = Number(e.target.dataset.value);
      saveRating(univ,val); applyAll(); alert(`Saved ${val}★ for "${univ}" (stored locally)`); 
    });
  });
}

function renderStars(avg){
  let out = '<span class="stars" aria-hidden="true">';
  for(let i=1;i<=5;i++){ const cls = (avg && avg >= (i-0.25)) ? 'star active' : 'star'; out += `<span class="${cls}" data-value="${i}">★</span>`; }
  out += '</span>'; out += avg?` <span class="kv"> ${avg.toFixed(1)}</span>`:` <span class="kv">(no ratings)</span>`;
  return out;
}

function loadRatings(){ try{ return JSON.parse(localStorage.getItem(LS_RATINGS)||'{}'); }catch(e){return{}} }
function saveRatings(obj){ localStorage.setItem(LS_RATINGS, JSON.stringify(obj)); }
function saveRating(univ, value){ const all = loadRatings(); if(!all[univ]) all[univ]={sum:0,count:0}; all[univ].sum+=value; all[univ].count+=1; saveRatings(all); }

// NOTES (localStorage) or Firebase if configured
function loadNotes(){ try{ return JSON.parse(localStorage.getItem(LS_NOTES)||'[]'); }catch(e){return[];} }
function saveNote(){
  const name = $('#noteName').value.trim()||'anon';
  const univ = $('#noteUniv').value.trim()||'';
  const text = $('#noteText').value.trim()||'';
  const rating = $('#noteRating').value?Number($('#noteRating').value):null;
  if(!text && !rating && !univ){ alert('Add a short note, choose a university, or add a rating.'); return; }
  // If Firebase is configured and available, push to Firebase Realtime Database
  if(window.firebase && window.firebase.database && window.FIREBASE_CONFIG && window.FIREBASE_CONFIG.projectId){
    const db = firebase.database();
    const ref = db.ref('notes');
    const payload = { name, univ, text, rating, ts: Date.now() };
    ref.push(payload).then(()=>{ $('#noteForm').reset(); renderNotes(); alert('Saved note to Firebase.'); }).catch(err=>{ console.error(err); alert('Failed to save to Firebase. Saved locally instead.'); saveNoteLocal({name,univ,text,rating,ts:Date.now()}); });
    return;
  }
  saveNoteLocal({name,univ,text,rating,ts:Date.now()});
}
function saveNoteLocal(obj){
  const arr = loadNotes(); arr.unshift(obj); localStorage.setItem(LS_NOTES, JSON.stringify(arr)); $('#noteForm').reset(); renderNotes();
}
function renderNotes(){
  // If Firebase available, load from DB; otherwise localStorage
  if(window.firebase && window.firebase.database && window.FIREBASE_CONFIG && window.FIREBASE_CONFIG.projectId){
    const db = firebase.database();
    const ref = db.ref('notes').orderByChild('ts').limitToLast(200);
    ref.on('value', snapshot=>{
      const val = snapshot.val()||{};
      const arr = Object.keys(val).map(k=>val[k]).sort((a,b)=>b.ts - a.ts);
      renderNotesList(arr);
    });
  } else {
    const arr = loadNotes();
    renderNotesList(arr);
  }
}
function renderNotesList(arr){
  const out = $('#notesList'); if(!arr.length){ out.innerHTML = '<p class="kv">No notes yet.</p>'; return; }
  out.innerHTML = arr.map(n=>`<div class="note"><div class="meta">${escapeHtml(n.name)} ${n.univ?`— ${escapeHtml(n.univ)}`:''} <span class="kv">(${new Date(n.ts).toLocaleString()})</span></div><div class="body">${escapeHtml(n.text||'')} ${n.rating?`<div class="kv">Rating: ${'★'.repeat(n.rating)}</div>`:''}</div></div>`).join('');
}

// Export to CSV
function exportToCSV(rows){
  if(!rows || !rows.length){ alert('No rows to export'); return; }
  const header = ['rank','university','country','score'];
  const lines = [ header.join(',') ];
  rows.forEach(r=>{
    const line = [ r.rank, '"' + String(r.university).replace(/"/g,'""') + '"', '"' + String(r.country).replace(/"/g,'""') + '"', r.score!==null?r.score:'' ].join(',');
    lines.push(line);
  });
  const csv = lines.join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'ediguide_rankings.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

// Utilities
function escapeHtml(str){ if(!str) return ''; return String(str).replace(/[&<>"']/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s])); }
function loadOptionalScriptInline(src){ return new Promise((res,rej)=>{ fetch(src).then(r=>r.ok?res():rej()).catch(rej); }); }

// Firebase initialization helper (compat)
function initFirebase(config){
  try{
    if(!window.firebase){ console.warn('Firebase scripts not loaded.'); return; }
    firebase.initializeApp(config);
    console.log('Firebase initialized');
    // optional: set up auth if desired
  }catch(e){ console.error('initFirebase',e); }
}
